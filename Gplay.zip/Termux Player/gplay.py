import os
import sys
import time
import random
import argparse
import pygame
from colorama import init, Fore, Style
from mutagen.mp3 import MP3
from mutagen.id3 import ID3, error
from pathlib import Path
from typing import List, Optional

class MP3Player:
    def __init__(self):
        pygame.mixer.init()
        self.playlist: List[str] = []
        self.current_index = 0
        self.is_playing = False
        self.is_paused = False
        self.volume = 0.5

    def load_playlist(self, directory: str) -> None:
        """Load MP3 files from a directory into playlist"""
        self.playlist = []
        for file in Path(directory).rglob('*.mp3'):
            self.playlist.append(str(file))
        self.playlist.sort()
        self.current_index = 0

    def play(self, index: Optional[int] = None) -> None:
        """Play a specific track or continue from current position"""
        if not self.playlist:
            print(Fore.RED + "No songs in playlist!" + Style.RESET_ALL)
            return

        if index is not None:
            self.current_index = index

        try:
            pygame.mixer.music.load(self.playlist[self.current_index])
            pygame.mixer.music.play()
            self.is_playing = True
            self.is_paused = False
            self._display_track_info()
        except Exception as e:
            print(Fore.RED + f"Error playing track: {str(e)}" + Style.RESET_ALL)

    def pause(self) -> None:
        """Pause the current track"""
        if self.is_playing:
            pygame.mixer.music.pause()
            self.is_paused = True

    def resume(self) -> None:
        """Resume the current track"""
        if self.is_paused:
            pygame.mixer.music.unpause()
            self.is_paused = False

    def next_track(self) -> None:
        """Play next track in playlist"""
        if not self.playlist:
            return

        self.current_index = (self.current_index + 1) % len(self.playlist)
        self.play()

    def previous_track(self) -> None:
        """Play previous track in playlist"""
        if not self.playlist:
            return

        self.current_index = (self.current_index - 1) % len(self.playlist)
        self.play()

    def stop(self) -> None:
        """Stop playback"""
        pygame.mixer.music.stop()
        self.is_playing = False
        self.is_paused = False

    def set_volume(self, volume: float) -> None:
        """Set playback volume (0.0 to 1.0)"""
        pygame.mixer.music.set_volume(volume)
        self.volume = volume

    def _display_track_info(self) -> None:
        """Display information about the current track"""
        try:
            audio = MP3(self.playlist[self.current_index])
            tags = ID3(self.playlist[self.current_index])
            
            title = tags.get('TIT2', ['Unknown'])[0]
            artist = tags.get('TPE1', ['Unknown'])[0]
            length = time.strftime('%M:%S', time.gmtime(audio.info.length))
            
            print(f"\n{Fore.GREEN}Now playing:{Style.RESET_ALL}")
            print(f"{Fore.CYAN}Title:{Style.RESET_ALL} {title}")
            print(f"{Fore.CYAN}Artist:{Style.RESET_ALL} {artist}")
            print(f"{Fore.CYAN}Duration:{Style.RESET_ALL} {length}")
            print(f"{Fore.CYAN}Track {self.current_index + 1}/{len(self.playlist)}{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.YELLOW}Could not read track info: {str(e)}{Style.RESET_ALL}")

def main():
    parser = argparse.ArgumentParser(description='GPlay - A Command Line MP3 Player')
    parser.add_argument('directory', nargs='?', default='.', 
                        help='Directory containing MP3 files')
    parser.add_argument('-p', '--play', action='store_true',
                        help='Play the first track')
    parser.add_argument('-s', '--stop', action='store_true',
                        help='Stop playback')
    parser.add_argument('-n', '--next', action='store_true',
                        help='Play next track')
    parser.add_argument('-r', '--previous', action='store_true',
                        help='Play previous track')
    parser.add_argument('-v', '--volume', type=float, default=None,
                        help='Set volume (0.0 to 1.0)')
    
    args = parser.parse_args()

    player = MP3Player()
    
    # Load playlist
    player.load_playlist(args.directory)
    
    # Process commands
    if args.play:
        player.play()
    elif args.stop:
        player.stop()
    elif args.next:
        player.next_track()
    elif args.previous:
        player.previous_track()
    elif args.volume is not None:
        player.set_volume(args.volume)
    else:
        # Interactive mode
        print("\n" + "="*50)
        print(f"{Fore.GREEN}GPlay - Command Line MP3 Player{Style.RESET_ALL}")
        print("="*50)
        print("\nCommands:")
        print("  p - Play/Pause")
        print("  n - Next track")
        print("  r - Previous track")
        print("  s - Stop")
        print("  v - Set volume (0.0 to 1.0)")
        print("  q - Quit")
        print("\n" + "="*50 + "\n")
        
        while True:
            command = input("\nEnter command: ").lower()
            
            if command == 'p':
                if player.is_playing and not player.is_paused:
                    player.pause()
                else:
                    player.resume()
            elif command == 'n':
                player.next_track()
            elif command == 'r':
                player.previous_track()
            elif command == 's':
                player.stop()
                break
            elif command == 'v':
                try:
                    vol = float(input("Enter volume (0.0 to 1.0): "))
                    if 0.0 <= vol <= 1.0:
                        player.set_volume(vol)
                    else:
                        print(Fore.RED + "Volume must be between 0.0 and 1.0" + Style.RESET_ALL)
                except ValueError:
                    print(Fore.RED + "Invalid volume value" + Style.RESET_ALL)
            elif command == 'q':
                player.stop()
                break
            else:
                print(Fore.RED + "Invalid command!" + Style.RESET_ALL)

if __name__ == "__main__":
    init()  # Initialize colorama
    main()
