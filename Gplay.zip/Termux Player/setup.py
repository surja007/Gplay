from setuptools import setup

setup(
    name="gplay",
    version="1.0.0",
    description="A cross-platform command line MP3 player",
    author="Your Name",
    author_email="your.email@example.com",
    packages=["gplay"],
    entry_points={
        'console_scripts': [
            'gplay=gplay:main'
        ]
    },
    install_requires=[
        'pygame==2.5.2',
        'colorama==0.4.6',
        'mutagen==1.47.0'
    ],
    python_requires='>=3.6',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)
